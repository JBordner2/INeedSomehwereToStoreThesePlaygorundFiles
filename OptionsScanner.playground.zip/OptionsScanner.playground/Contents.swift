import UIKit


/*
 
 The fish I hunt:
    
    FRIDAY BEAR MARKET RALLY PUTS
        Description: When markets are in a bear market rally, look for opportunies to by cheap options after open on Friday and sell withing 30 minutes
            Concerns would be:
                - Markets do not move much => RISK MITIGATION: Sell within 30 minutes
        
    The 10 year banger:
        Description: Buy some stock that I plan to hold for 10 years. Anytime the stock pulls back 10 percen, buy some more
            Concerns Would Be:
                - I continue to buy as the stock continues to fall and therefore lose all my captial => RISK MITIGATION: I invest in stocks that fit the guide of "The Inteligent Invetor" and do not use more than 27.5 percent of my total portfolio for this
 
    Chris's CAN SLIM:
        Description: Combine Chris Camillo and William O'Neil for a can slim styled approach of investing.
            Concerns Would Be:
                - I struggle with exiting my position or cutting losses at 8 percent
                - I use too much capital per position
 
    Cash flowing crop:
        Description: Positions that I can sell covered calls against:
            Concerns Would Be:
                - I don't understand all the risks and rewards / tax implications
 
    Dying Crops:
        Description: Shorting stocks that have ran up lot in price in a small amount of time
            - I expose myself to massive risk
 
    THE FRIDAY SPREAD:
        Description: OTM calls and OTM puts on a given position
            Concerns would be:
                - Markets do not move much => RISK MITIGATION: Sell within 30 minutes
                    
 
    THE TREND:
        Description: 4 - 6 week ITM option speicifically on a position that is likely to trend well with a market
            Concerns would be:
                - Volatile markets
            
 
 */



/*
 
 
 Useful trading programs I've written:
    - program for buying spreads that I am looking to get in or out of within 30 min
    - program for canceling open orders
 
        These two could be useful in the scenario of creating a spread order and only wanting one of the two orders canceled
    - program that cancels existing call orders
    - program that cancels existing put orders
 
    - program that calculates the average volume for a given stock in the first 15, 30, 45 & 60 min over the last 3, 5, 10, 20 and 30 days
    - program that compares current volume to the averages calculated above
        - maybe the quickest way of doing this would be to store the data locally and then compare the current volume to the local average
        - could also get the 1 min average each day for the last 3, 5, 10, 20 & 30 days and then compare the volume at the current min to those averages
 
    - on etrade orders need to be previewed before they can be place so create method that will preview order
 
 
    The 3 percent gain scanner
        -
 
 */



func threeAndHalfGainTwoAndAHalfLoss(_ cash: Double = 500, winningTrades: Int, losingTrades: Int) {
    
    var cash = cash
    var x = 0
    let trades = generateWinningLossTradeDictionary(numberOfWins: winningTrades, numberOfLosses: losingTrades)
    
    print("Starting Cash: \(cash)")
    
    while x < trades.count {
        if trades[x].didGainMoney {
            print("cash before trade: \(cash)")
            cash = cash * 1.035
            print("cash after trade: \(cash)")
        } else {
            print("cash before trade: \(cash)")
            cash = cash * 0.975
            print("cash after trade: \(cash)")
        }
        
        print("************************************************")
        print("\n")
        x += 1
    }
}


struct Trade {
    let didGainMoney: Bool
}

func generateWinningLossTradeDictionary(numberOfWins: Int, numberOfLosses: Int) -> [Trade] {
    var returnedTrades = [Trade]()
    
    for _ in 1...numberOfWins {
        let trade = Trade(didGainMoney: true)
        returnedTrades.append(trade)
    }
    
    for _ in 1...numberOfLosses {
        let trade = Trade(didGainMoney: false)
        returnedTrades.append(trade)
    }
    
    return returnedTrades
}

 
// If the program is right 47 percent of the time then it makes money..... probably not a good system....
threeAndHalfGainTwoAndAHalfLoss(winningTrades: 8, losingTrades: 10)



